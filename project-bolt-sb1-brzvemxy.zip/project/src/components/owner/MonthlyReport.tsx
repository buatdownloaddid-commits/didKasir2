import { useCallback, useEffect, useMemo, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { formatDate, formatRupiah, type Store, type Transaction } from '../../lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Skeleton } from '../ui/skeleton';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '../ui/dialog';
import { AlertCircle, BarChart3, KeyRound, Package, ReceiptText, RotateCcw, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';

type SellerRow = {
  id: string;
  name: string;
  qty: number;
  revenue: number;
};

export default function MonthlyReport({ store }: { store: Store }) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [resetAt, setResetAt] = useState(store.monthly_report_reset_at);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const [pin, setPin] = useState('');
  const [resetting, setResetting] = useState(false);

  const reportStart = useMemo(() => getReportStart(resetAt), [resetAt]);

  const load = useCallback(async () => {
    setError(false);
    const { data, error: queryError } = await supabase
      .from('transactions')
      .select('*')
      .eq('store_token', store.token)
      .in('status', ['confirmed', 'done'])
      .gte('created_at', reportStart.toISOString())
      .order('created_at', { ascending: false });

    if (queryError) {
      setError(true);
      setLoading(false);
      return;
    }

    setTransactions((data ?? []) as Transaction[]);
    setLoading(false);
  }, [reportStart, store.token]);

  useEffect(() => {
    load();
    const channel = supabase
      .channel(`monthly-report-${store.token}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'transactions',
          filter: `store_token=eq.${store.token}`,
        },
        () => load()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [load, store.token]);

  const totalSales = transactions.reduce((sum, transaction) => sum + Number(transaction.total), 0);
  const totalProfit = transactions.reduce((sum, transaction) => sum + Number(transaction.profit), 0);

  const bestSelling = useMemo(() => {
    const map = new Map<string, SellerRow>();
    for (const transaction of transactions) {
      for (const item of transaction.items ?? []) {
        const current = map.get(item.id);
        if (current) {
          current.qty += item.qty;
          current.revenue += item.price * item.qty;
        } else {
          map.set(item.id, {
            id: item.id,
            name: item.name,
            qty: item.qty,
            revenue: item.price * item.qty,
          });
        }
      }
    }
    return Array.from(map.values()).sort((a, b) => b.qty - a.qty || a.name.localeCompare(b.name));
  }, [transactions]);

  async function resetReport() {
    if (!pin.trim()) {
      toast.error('Masukkan PIN login pemilik');
      return;
    }
    setResetting(true);
    const { data, error: resetError } = await supabase.rpc('reset_monthly_report', {
      p_store_token: store.token,
      p_pin: pin,
    });
    setResetting(false);
    if (resetError || typeof data !== 'string') {
      toast.error('PIN login salah atau laporan gagal direset');
      return;
    }
    setResetAt(data);
    setTransactions([]);
    setPin('');
    setResetOpen(false);
    toast.success('Laporan berhasil direset');
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-xl font-extrabold tracking-tight">Laporan Bulanan</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Periode {formatDate(reportStart.toISOString())} sampai hari ini.
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={() => setResetOpen(true)}>
          <RotateCcw className="mr-1.5 h-4 w-4" /> Reset
        </Button>
      </div>

      {error && (
        <Card className="border-destructive/30 bg-destructive/5">
          <CardContent className="flex items-start gap-3 p-4 text-sm text-destructive">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            <p>Laporan belum dapat dimuat. Periksa koneksi lalu buka menu ini kembali.</p>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <ReportStat
          icon={<ReceiptText className="h-5 w-5" />}
          label="Total Transaksi"
          value={`${transactions.length}`}
          loading={loading}
        />
        <ReportStat
          icon={<BarChart3 className="h-5 w-5" />}
          label="Omset"
          value={formatRupiah(totalSales)}
          loading={loading}
        />
        <ReportStat
          icon={<TrendingUp className="h-5 w-5" />}
          label="Keuntungan Bersih"
          value={formatRupiah(totalProfit)}
          loading={loading}
          accent
        />
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <Package className="h-5 w-5 text-primary" /> Produk Terlaris
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-2">
          {loading ? (
            <Skeleton className="h-24 w-full" />
          ) : bestSelling.length === 0 ? (
            <p className="text-sm text-muted-foreground">Belum ada transaksi selesai pada periode ini.</p>
          ) : (
            bestSelling.slice(0, 10).map((item, index) => (
              <div key={item.id} className="flex items-center justify-between gap-3 rounded-lg border p-3">
                <div className="flex min-w-0 items-center gap-3">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary">
                    {index + 1}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate font-semibold">{item.name}</p>
                    <p className="text-xs text-muted-foreground">Omset {formatRupiah(item.revenue)}</p>
                  </div>
                </div>
                <p className="shrink-0 text-sm font-extrabold text-primary">{item.qty} terjual</p>
              </div>
            ))
          )}
        </CardContent>
      </Card>

      <Dialog open={resetOpen} onOpenChange={setResetOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reset laporan bulanan?</DialogTitle>
            <DialogDescription>
              Transaksi tidak akan dihapus. Laporan hanya akan mulai menghitung dari waktu reset.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="report-pin">PIN login pemilik</Label>
              <Input
                id="report-pin"
                type="password"
                value={pin}
                onChange={(event) => setPin(event.target.value)}
                placeholder="Masukkan password saat masuk"
                autoComplete="current-password"
              />
            </div>
            <Button onClick={resetReport} disabled={resetting}>
              {resetting ? <RotateCcw className="mr-2 h-4 w-4 animate-spin" /> : <KeyRound className="mr-2 h-4 w-4" />}
              Konfirmasi Reset
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ReportStat({
  icon,
  label,
  value,
  loading,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  loading: boolean;
  accent?: boolean;
}) {
  return (
    <Card className={accent ? 'border-primary/30 bg-primary/5' : ''}>
      <CardContent className="flex items-center gap-3 p-4">
        <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${accent ? 'bg-primary text-white' : 'bg-primary/10 text-primary'}`}>
          {icon}
        </div>
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground">{label}</p>
          {loading ? <Skeleton className="mt-1 h-6 w-24" /> : <p className="truncate text-lg font-extrabold">{value}</p>}
        </div>
      </CardContent>
    </Card>
  );
}

function getReportStart(resetAt: string | null): Date {
  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);
  if (!resetAt) return monthStart;
  const resetDate = new Date(resetAt);
  return resetDate > monthStart ? resetDate : monthStart;
}
