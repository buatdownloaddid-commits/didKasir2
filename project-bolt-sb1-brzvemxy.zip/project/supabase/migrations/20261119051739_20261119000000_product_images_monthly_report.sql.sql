/*
# Product images and resettable monthly reports

1. New columns
- `products.image_url`: public URL of the product image shown in the owner catalog and customer catalog.
- `stores.monthly_report_reset_at`: start time of the current reporting period. It lets the owner reset the report without deleting transaction history.

2. Storage
- Creates the public `product-images` bucket for customer-facing product photos.
- Limits uploads to 5 MB and JPEG, PNG, or WebP MIME types.
- Allows public reads so customers can see catalog images.
- Allows uploads only inside a folder named with an existing store token and only for approved image MIME types.

3. Monthly report reset
- Adds `reset_monthly_report(store_token, pin)`, a server-side function that checks the store login password as the owner PIN and advances `monthly_report_reset_at`.
- The reset does not delete transactions, products, or customer data; it only starts a new reporting period.

4. Security
- Keeps the existing single-tenant/no-auth access model used by this app (`anon` and `authenticated`).
- The reset function uses a fixed `public` search path and returns only the new timestamp.
- Storage write checks are scoped to the product-images bucket, valid store-token folders, and approved image MIME types.
*/

ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS image_url text;

ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS monthly_report_reset_at timestamptz;

UPDATE public.stores
SET monthly_report_reset_at = date_trunc('month', now())
WHERE monthly_report_reset_at IS NULL;

ALTER TABLE public.stores
  ALTER COLUMN monthly_report_reset_at SET DEFAULT date_trunc('month', now());

CREATE INDEX IF NOT EXISTS idx_transactions_store_created_at
  ON public.transactions(store_token, created_at);

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'product-images',
  'product-images',
  true,
  5242880,
  ARRAY['image/jpeg', 'image/png', 'image/webp']::text[]
)
ON CONFLICT (id) DO UPDATE
SET public = EXCLUDED.public,
    file_size_limit = EXCLUDED.file_size_limit,
    allowed_mime_types = EXCLUDED.allowed_mime_types;

DROP POLICY IF EXISTS "public read product images" ON storage.objects;
CREATE POLICY "public read product images"
ON storage.objects FOR SELECT
TO anon, authenticated
USING (bucket_id = 'product-images');

DROP POLICY IF EXISTS "upload store product images" ON storage.objects;
CREATE POLICY "upload store product images"
ON storage.objects FOR INSERT
TO anon, authenticated
WITH CHECK (
  bucket_id = 'product-images'
  AND (storage.foldername(name))[1] IN (SELECT token FROM public.stores)
  AND lower(coalesce(metadata->>'mimetype', '')) IN ('image/jpeg', 'image/png', 'image/webp')
);

DROP POLICY IF EXISTS "update store product images" ON storage.objects;
CREATE POLICY "update store product images"
ON storage.objects FOR UPDATE
TO anon, authenticated
USING (
  bucket_id = 'product-images'
  AND (storage.foldername(name))[1] IN (SELECT token FROM public.stores)
)
WITH CHECK (
  bucket_id = 'product-images'
  AND (storage.foldername(name))[1] IN (SELECT token FROM public.stores)
  AND lower(coalesce(metadata->>'mimetype', '')) IN ('image/jpeg', 'image/png', 'image/webp')
);

CREATE OR REPLACE FUNCTION public.reset_monthly_report(p_store_token text, p_pin text)
RETURNS timestamptz
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_reset_at timestamptz;
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM public.stores
    WHERE token = p_store_token
      AND password = p_pin
  ) THEN
    RAISE EXCEPTION 'Invalid owner PIN';
  END IF;

  UPDATE public.stores
  SET monthly_report_reset_at = now()
  WHERE token = p_store_token
  RETURNING monthly_report_reset_at INTO v_reset_at;

  RETURN v_reset_at;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.reset_monthly_report(text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.reset_monthly_report(text, text) TO anon, authenticated;
